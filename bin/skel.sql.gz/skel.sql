-- TouchDownCenter Database Structure
-- TDC Version 3.7.50
-- extract from database of Client 'forestlake' on server tdc.my247now.com 
-- should only be use on emergency recovery 

SET NAMES utf8;

DROP TABLE IF EXISTS `alert_email_history`;
CREATE TABLE `alert_email_history` (
  `idx` int unsigned NOT NULL AUTO_INCREMENT,
  `dvr_id` varchar(45) NOT NULL,
  `date_time` datetime NOT NULL,
  `alert_code` int unsigned NOT NULL DEFAULT '0',
  `param1` int unsigned NOT NULL DEFAULT '0',
  `param2` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idx`),
  KEY `Index_2` (`date_time`,`dvr_id`) USING BTREE
) ;


DROP TABLE IF EXISTS `app_report`;
CREATE TABLE `app_report` (
  `ar_id` int NOT NULL AUTO_INCREMENT,
  `ar_name` varchar(50) NOT NULL,
  `ar_sql` varchar(400) DEFAULT NULL,
  `ar_webpage` varchar(60) DEFAULT NULL,
  `ar_target` varchar(45) NOT NULL,
  PRIMARY KEY (`ar_id`),
  UNIQUE KEY `ar_name` (`ar_name`)
) ;


DROP TABLE IF EXISTS `app_settings`;
CREATE TABLE `app_settings` (
  `app_id` int NOT NULL AUTO_INCREMENT,
  `app_name` varchar(30) NOT NULL,
  `app_desc` varchar(100) DEFAULT NULL,
  `app_value` varchar(30) NOT NULL,
  PRIMARY KEY (`app_id`),
  UNIQUE KEY `app_name` (`app_name`)
) ;


DROP TABLE IF EXISTS `app_user`;
CREATE TABLE `app_user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) DEFAULT NULL,
  `user_password` varchar(200) DEFAULT NULL,
  `user_type` varchar(10) DEFAULT 'user',
  `real_name` varchar(45) DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telephone` varchar(45) DEFAULT NULL,
  `title` varchar(45) DEFAULT NULL,
  `notify_requested_video` tinyint(1) DEFAULT NULL,
  `notify_marked_video` tinyint(1) DEFAULT NULL,
  `notify_sys_health` tinyint(1) DEFAULT NULL,
  `last_logon` datetime DEFAULT NULL,
  `shadow` varchar(130) DEFAULT NULL,
  `user_access` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ;

INSERT INTO `app_user` (`user_name`, `user_password`, `user_type`) VALUES ('admin','','admin');

DROP TABLE IF EXISTS `ass_d_v`;
CREATE TABLE `ass_d_v` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ass_vehicle_id` int DEFAULT NULL,
  `ass_driver_id` int DEFAULT NULL,
  `ass_vehicle_name` varchar(30) DEFAULT NULL,
  `ass_driver_first_name` varchar(30) DEFAULT NULL,
  `ass_driver_last_name` varchar(30) DEFAULT NULL,
  `ass_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ;


DROP TABLE IF EXISTS `avl_raw`;
CREATE TABLE `avl_raw` (
  `serialNum` int unsigned NOT NULL AUTO_INCREMENT,
  `vehicle_id` varchar(45) NOT NULL,
  `date_time` datetime NOT NULL,
  `raw_avl` varchar(1000) NOT NULL,
  `mss_header` varbinary(32) DEFAULT NULL,
  PRIMARY KEY (`serialNum`) USING BTREE,
  KEY `Index_2` (`date_time`,`vehicle_id`)
) ;


DROP TABLE IF EXISTS `clientlist`;
CREATE TABLE `clientlist` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(45) DEFAULT NULL,
  `customerNo` varchar(45) DEFAULT NULL,
  `lob` varchar(45) DEFAULT NULL,
  `prgp` varchar(45) DEFAULT NULL,
  `svcunq` varchar(45) DEFAULT NULL,
  `svqnty` varchar(45) DEFAULT NULL,
  `svcode` varchar(45) DEFAULT NULL,
  `svdesc_c` varchar(45) DEFAULT NULL,
  `size_c` varchar(45) DEFAULT NULL,
  `mat_c` varchar(45) DEFAULT NULL,
  `svroutnumb` varchar(45) DEFAULT NULL,
  `service_nm` varchar(45) DEFAULT NULL,
  `houseNo` varchar(45) DEFAULT NULL,
  `service_street_nm` varchar(45) DEFAULT NULL,
  `service_city` varchar(45) DEFAULT NULL,
  `service_state` varchar(45) DEFAULT NULL,
  `service_zip` varchar(45) DEFAULT NULL,
  `day` varchar(45) DEFAULT NULL,
  `route` varchar(45) DEFAULT NULL,
  `lat` double DEFAULT '0',
  `lon` double DEFAULT '0',
  PRIMARY KEY (`index`),
  KEY `Index_2` (`service_state`,`service_city`,`service_street_nm`,`houseNo`)
) ;


DROP TABLE IF EXISTS `distance_report_temp`;
CREATE TABLE `distance_report_temp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vl_vehicle_name` varchar(45) DEFAULT NULL,
  `vl_driver_name` varchar(45) DEFAULT NULL,
  `vl_datetime` date DEFAULT NULL,
  `vl_distance` double DEFAULT NULL,
  `vl_duration` int DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;


DROP TABLE IF EXISTS `driver`;
CREATE TABLE `driver` (
  `driver_id` int NOT NULL AUTO_INCREMENT,
  `driver_first_name` varchar(30) NOT NULL,
  `driver_last_name` varchar(30) NOT NULL,
  `driver_password` varchar(20) DEFAULT NULL,
  `driver_License` varchar(50) NOT NULL,
  `driver_tel` varchar(50) DEFAULT NULL,
  `driver_add` varchar(150) DEFAULT NULL,
  `driver_sin` varchar(50) DEFAULT NULL,
  `driver_rfid` varchar(150) DEFAULT NULL,
  `driver_vehicle_name` varchar(30) DEFAULT NULL,
  `driver_country` varchar(45) DEFAULT 'United States',
  `driver_bcode` varchar(45) DEFAULT '0000',
  `driver_city` varchar(45) DEFAULT 'n/a',
  `driver_pcode` varchar(45) DEFAULT 'n/a',
  `driver_explevel` varchar(45) DEFAULT NULL,
  `driver_state` varchar(45) DEFAULT NULL,
  `driver_email` varchar(45) DEFAULT NULL,
  `driver_bcode2` varchar(45) DEFAULT NULL,
  `driver_driverid` varchar(45) DEFAULT NULL,
  `driver_notes` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`driver_id`)
) ;


DROP TABLE IF EXISTS `drive_by_event`;
CREATE TABLE `drive_by_event` (
  `idx` int unsigned NOT NULL AUTO_INCREMENT,
  `Client_Id` varchar(45) NOT NULL,
  `Bus_Id` varchar(45) NOT NULL,
  `Date_Time` datetime NOT NULL,
  `Lat` double NOT NULL,
  `Lon` double NOT NULL,
  `Video_Files` varchar(1000) NOT NULL,
  `Sensor_Status` varchar(45) NOT NULL,
  `event_status` varchar(45) NOT NULL DEFAULT 'new',
  `Plateofviolator` varchar(45) DEFAULT NULL,
  `imgquality` varchar(45) NOT NULL DEFAULT 'Good',
  `notes` varchar(200) DEFAULT NULL,
  `event_processedby` varchar(45) DEFAULT NULL,
  `event_processedtime` datetime DEFAULT NULL,
  `event_deleteby` varchar(45) DEFAULT NULL,
  `event_deletetime` datetime DEFAULT NULL,
  `report_status` varchar(45) NOT NULL DEFAULT 'new',
  `report_file` varchar(200) DEFAULT NULL,
  `report_deleteby` varchar(45) DEFAULT NULL,
  `report_deletetime` datetime DEFAULT NULL,
  `email_status` varchar(45) NOT NULL DEFAULT 'Pending',
  `sentto` varchar(300) DEFAULT NULL,
  `State` varchar(45) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Extra` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `Index_2` (`Date_Time`)
) ;


DROP TABLE IF EXISTS `dvr_con`;
CREATE TABLE `dvr_con` (
  `con_id` int NOT NULL AUTO_INCREMENT,
  `con_signon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `con_vehicle_name` varchar(30) DEFAULT NULL,
  `con_ip` varchar(20) DEFAULT '0.0.0.0',
  `con_usb` varchar(20) DEFAULT 'abcd1234',
  `con_ready_f` varchar(1) DEFAULT '1',
  `con_ok_f` varchar(1) DEFAULT '0',
  `con_error_f` varchar(1) DEFAULT '0',
  `con_desc` varchar(50) DEFAULT ' ',
  `con_read` varchar(1) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '0',
  PRIMARY KEY (`con_id`)
) ;


DROP TABLE IF EXISTS `dvr_event`;
CREATE TABLE `dvr_event` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `de_vehicle_name` varchar(45) NOT NULL,
  `de_datetime` datetime NOT NULL,
  `de_event` int unsigned DEFAULT NULL,
  `de_param1` int unsigned DEFAULT NULL,
  `de_param2` int unsigned DEFAULT NULL,
  `de_detail` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Index_2` (`de_vehicle_name`),
  KEY `Index_3` (`de_vehicle_name`,`de_datetime`)
) ;


DROP TABLE IF EXISTS `dvr_sensor`;
CREATE TABLE `dvr_sensor` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `sensor_index` varchar(45) DEFAULT NULL,
  `sensor_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`index`)
) ;

INSERT INTO `dvr_sensor` (`index`, `sensor_index`, `sensor_name`) VALUES
(1,	'Sensor 1 Low',	NULL),
(2,	'Sensor 1 High',	NULL),
(3,	'Sensor 2 Low',	'Stop Arm On'),
(4,	'Sensor 2 High',	'Stop Arm Off'),
(5,	'Sensor 3 Low',	NULL),
(6,	'Sensor 3 High',	NULL),
(7,	'Sensor 4 Low',	NULL),
(8,	'Sensor 4 High',	NULL),
(9,	'Sensor 5 Low',	NULL),
(10,	'Sensor 5 High',	NULL),
(11,	'Sensor 6 Low',	NULL),
(12,	'Sensor 6 High',	NULL),
(13,	'Sensor 7 Low',	NULL),
(14,	'Sensor 7 High',	NULL),
(15,	'Sensor 8 Low',	NULL),
(16,	'Sensor 8 High',	NULL),
(17,	'Sensor 9 Low',	NULL),
(18,	'Sensor 9 High',	NULL),
(19,	'Sensor 10 Low',	NULL),
(20,	'Sensor 10 High',	NULL),
(21,	'Sensor 11 Low',	NULL),
(22,	'Sensor 11 High',	NULL),
(23,	'Sensor 12 Low',	NULL),
(24,	'Sensor 12 High',	NULL),
(25,	'Sensor 13 Low',	NULL),
(26,	'Sensor 13 High',	NULL),
(27,	'Sensor 14 Low',	NULL),
(28,	'Sensor 14 High',	NULL),
(29,	'Sensor 15 Low',	NULL),
(30,	'Sensor 15 High',	NULL),
(31,	'Sensor 16 Low',	NULL),
(32,	'Sensor 16 High',	NULL);

DROP TABLE IF EXISTS `dvr_vuf`;
CREATE TABLE `dvr_vuf` (
  `vuf_id` int NOT NULL AUTO_INCREMENT,
  `vuf_dir` varchar(150) DEFAULT NULL,
  `vuf_name` varchar(50) DEFAULT NULL,
  `vuf_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vuf_vehicle_name` varchar(30) DEFAULT NULL,
  `vuf_flag` varchar(1) DEFAULT '0',
  `vuf_delflag` varchar(1) DEFAULT '0',
  `vuf_read_flag` varchar(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vuf_id`),
  UNIQUE KEY `vuf_dir` (`vuf_dir`)
) ;


DROP TABLE IF EXISTS `emg_event`;
CREATE TABLE `emg_event` (
  `idx` int unsigned NOT NULL AUTO_INCREMENT,
  `Client_Id` varchar(45) NOT NULL,
  `Bus_Id` varchar(45) NOT NULL,
  `Date_Time` datetime NOT NULL,
  `Lat` double NOT NULL,
  `Lon` double NOT NULL,
  `Video_Files` varchar(1000) NOT NULL,
  `Sensor_Status` varchar(45) NOT NULL,
  `Event_Code` int unsigned NOT NULL,
  PRIMARY KEY (`idx`),
  KEY `Index_2` (`Date_Time`)
) ;


DROP TABLE IF EXISTS `event_list`;
CREATE TABLE `event_list` (
  `Event_name` varchar(30) NOT NULL,
  `Event_Number` int NOT NULL,
  PRIMARY KEY (`Event_name`)
) ;


DROP TABLE IF EXISTS `ivuconfig`;
CREATE TABLE `ivuconfig` (
  `SerialNo` int unsigned NOT NULL AUTO_INCREMENT,
  `IvuId` varchar(45) NOT NULL,
  `VehicleName` varchar(45) DEFAULT NULL,
  `TimeZone` varchar(100) DEFAULT NULL,
  `SensorName` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`SerialNo`),
  KEY `Index_2` (`IvuId`),
  KEY `Index_3` (`VehicleName`)
) ;


DROP TABLE IF EXISTS `lt_history`;
CREATE TABLE `lt_history` (
  `idx` int unsigned NOT NULL AUTO_INCREMENT,
  `dvr_name` varchar(45) NOT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `speed` double NOT NULL,
  `direction` double NOT NULL,
  `sensor_status` int unsigned DEFAULT NULL,
  `sensor_mask` int unsigned DEFAULT NULL,
  `event_code` int unsigned NOT NULL,
  `gforce_x` double DEFAULT NULL,
  `gforce_y` double DEFAULT NULL,
  `gforce_z` double DEFAULT NULL,
  `geo_fence` varchar(200) DEFAULT NULL,
  `event_param` int DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `Index_2` (`dvr_name`,`date_time`,`event_code`),
  KEY `Index_3` (`date_time`,`dvr_name`,`event_code`)
) ;


DROP TABLE IF EXISTS `map_cur`;
CREATE TABLE `map_cur` (
  `map_id` int NOT NULL AUTO_INCREMENT,
  `map_user_name` varchar(30) NOT NULL,
  `map_vehicle_name` varchar(30) NOT NULL,
  `map_curr_time` datetime DEFAULT NULL,
  `map_flag` varchar(1) NOT NULL DEFAULT '1',
  `map_up` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `map_ip` varchar(45) DEFAULT '0.0.0.0',
  PRIMARY KEY (`map_id`)
) ;


DROP TABLE IF EXISTS `missing_fragments`;
CREATE TABLE `missing_fragments` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `task_id` varchar(250) NOT NULL,
  `dvr_id` varchar(45) NOT NULL,
  `file_name` varchar(250) NOT NULL,
  `fragment` int unsigned NOT NULL,
  PRIMARY KEY (`index`)
) ;


DROP TABLE IF EXISTS `mss`;
CREATE TABLE `mss` (
  `idx` int unsigned NOT NULL AUTO_INCREMENT,
  `mss_id` varchar(45) NOT NULL,
  `mss_maxlogin` int unsigned NOT NULL,
  `mss_lastlogin` datetime DEFAULT '2000-01-01 00:00:00',
  `mss_hddErr` int unsigned DEFAULT '0',
  `mss_sd1Err` int unsigned DEFAULT '0',
  `mss_sd2Err` int unsigned DEFAULT '0',
  `mss_apCount` int unsigned DEFAULT '0',
  `mss_apErr` int unsigned DEFAULT '0',
  `mss_lat` double DEFAULT '0',
  `mss_lon` double DEFAULT '0',
  `mss_hddOld` int unsigned DEFAULT '0',
  `mss_sd1Old` int unsigned DEFAULT '0',
  `mss_sd2Old` int unsigned DEFAULT '0',
  `mss_apOld` int unsigned DEFAULT '0',
  `mss_connectOld` int unsigned DEFAULT '0',
  PRIMARY KEY (`idx`)
) ;


DROP TABLE IF EXISTS `obd_data`;
CREATE TABLE `obd_data` (
  `serialNum` int unsigned NOT NULL AUTO_INCREMENT,
  `vehicle_name` varchar(45) NOT NULL,
  `date_time` datetime NOT NULL,
  `obd_code` int unsigned NOT NULL,
  `obd_value` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`serialNum`),
  KEY `Index_2` (`date_time`,`vehicle_name`) USING BTREE,
  KEY `Index_3` (`date_time`,`obd_code`) USING BTREE
) ;


DROP TABLE IF EXISTS `quickfilter`;
CREATE TABLE `quickfilter` (
  `idx` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `user` varchar(45) NOT NULL,
  `timeType` int unsigned NOT NULL,
  `startTime` datetime NOT NULL,
  `endTime` datetime NOT NULL,
  `vehicleType` int unsigned NOT NULL DEFAULT '0',
  `vehicleGroupName` varchar(45) NOT NULL,
  `zoneType` int unsigned NOT NULL DEFAULT '0',
  `zoneName` varchar(45) NOT NULL DEFAULT 'No Restriction',
  `bStop` tinyint(1) NOT NULL DEFAULT '1',
  `bIdling` tinyint(1) NOT NULL DEFAULT '1',
  `bParking` tinyint(1) NOT NULL DEFAULT '1',
  `bDesStop` tinyint(1) NOT NULL DEFAULT '1',
  `bSpeeding` tinyint(1) NOT NULL DEFAULT '1',
  `bRoute` tinyint(1) NOT NULL DEFAULT '1',
  `bEvent` tinyint(1) NOT NULL DEFAULT '1',
  `bRacingStart` tinyint(1) NOT NULL DEFAULT '1',
  `bHardBrake` tinyint(1) NOT NULL DEFAULT '1',
  `bHardTurn` tinyint(1) NOT NULL DEFAULT '1',
  `bFrontImpact` tinyint(1) NOT NULL DEFAULT '1',
  `bRearImpact` tinyint(1) NOT NULL DEFAULT '1',
  `bSideImpact` tinyint(1) NOT NULL DEFAULT '1',
  `bBumpyRide` tinyint(1) NOT NULL DEFAULT '1',
  `stopDuration` int unsigned NOT NULL DEFAULT '0',
  `idleDuration` int unsigned NOT NULL DEFAULT '0',
  `parkDuration` int unsigned NOT NULL DEFAULT '0',
  `desStopDuration` int unsigned NOT NULL DEFAULT '0',
  `speedLimit` double NOT NULL DEFAULT '0',
  `gRacingStart` double NOT NULL DEFAULT '0',
  `gHardBrake` double NOT NULL DEFAULT '0',
  `gHardTurn` double NOT NULL DEFAULT '0',
  `gFrontImpact` double NOT NULL DEFAULT '0',
  `gRearImpact` double NOT NULL DEFAULT '0',
  `gSideImpact` double NOT NULL DEFAULT '0',
  `gBumpyRide` double NOT NULL DEFAULT '0',
  `bDriveBy` tinyint(1) NOT NULL DEFAULT '1',
  `bDoorOpen` tinyint(1) NOT NULL DEFAULT '1',
  `bDoorClose` tinyint(1) NOT NULL DEFAULT '1',
  `bIgnitionOn` tinyint(1) NOT NULL DEFAULT '1',
  `bIgnitionOff` tinyint(1) NOT NULL DEFAULT '1',
  `bMeterOn` tinyint(1) NOT NULL DEFAULT '1',
  `bMeterOff` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idx`)
) ;


DROP TABLE IF EXISTS `report_parameter`;
CREATE TABLE `report_parameter` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `speed` double NOT NULL DEFAULT '0',
  `stop_duration` int unsigned NOT NULL DEFAULT '0',
  `idle_duration` int unsigned NOT NULL DEFAULT '0',
  `bstop_duration` int unsigned NOT NULL DEFAULT '0',
  `park_duration` int unsigned NOT NULL DEFAULT '0',
  `racing_start` double NOT NULL DEFAULT '0',
  `hard_brake` double NOT NULL DEFAULT '0',
  `rear_impact` double NOT NULL DEFAULT '0',
  `front_impact` double NOT NULL DEFAULT '0',
  `hard_turn` double NOT NULL DEFAULT '0',
  `side_impact` double NOT NULL DEFAULT '0',
  `bumpy_ride` double NOT NULL DEFAULT '0',
  `description` varchar(45) NOT NULL,
  `maxuploadtime` int unsigned NOT NULL DEFAULT '60',
  `maxconcurrentupload` int unsigned NOT NULL DEFAULT '10',
  `battery_low` int unsigned NOT NULL DEFAULT '12000',
  `park_too_long` int unsigned NOT NULL DEFAULT '120',
  PRIMARY KEY (`index`)
) ;

INSERT INTO `report_parameter` (`index`, `speed`, `stop_duration`, `idle_duration`, `bstop_duration`, `park_duration`, `racing_start`, `hard_brake`, `rear_impact`, `front_impact`, `hard_turn`, `side_impact`, `bumpy_ride`, `description`, `maxuploadtime`, `maxconcurrentupload`, `battery_low`, `park_too_long`) VALUES
(1,	60,	3,	1800,	3,	900,	0.5,	0.5,	0.8,	0.8,	0.5,	0.8,	0.5,	'userdefine',	3600,	10,	12000,	120);

DROP TABLE IF EXISTS `syslog`;
CREATE TABLE `syslog` (
  `sl_id` int unsigned NOT NULL AUTO_INCREMENT,
  `sl_user_id` varchar(45) DEFAULT NULL,
  `sl_action_type` varchar(45) DEFAULT NULL,
  `sl_action_time` datetime DEFAULT NULL,
  `sl_vehicle_id` varchar(45) DEFAULT NULL,
  `sl_officer_id` varchar(45) DEFAULT NULL,
  `sl_start_time` datetime DEFAULT NULL,
  `sl_end_time` datetime DEFAULT NULL,
  `sl_file_path` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`sl_id`),
  KEY `event` (`sl_action_type`) USING BTREE,
  KEY `datetime` (`sl_action_time`) USING BTREE,
  KEY `userid` (`sl_user_id`),
  KEY `vehicleid` (`sl_vehicle_id`),
  KEY `officerid` (`sl_officer_id`)
) ;


DROP TABLE IF EXISTS `tdconfig`;
CREATE TABLE `tdconfig` (
  `idx` int unsigned NOT NULL AUTO_INCREMENT,
  `smtpServer` varchar(45) DEFAULT NULL,
  `smtpServerPort` int unsigned DEFAULT NULL,
  `security` int unsigned DEFAULT NULL,
  `recipient` varchar(500) DEFAULT NULL,
  `authenticationUserName` varchar(45) DEFAULT NULL,
  `authenticationPassword` varchar(45) DEFAULT NULL,
  `senderAddr` varchar(45) DEFAULT NULL,
  `alertRecipients` varchar(500) DEFAULT NULL,
  `sendSummaryDaily` int unsigned DEFAULT NULL,
  `maxConcurrentUpload` int unsigned DEFAULT NULL,
  `resumeTransferAfterPause` int unsigned DEFAULT NULL,
  `tmSendDaily` datetime DEFAULT NULL,
  `senderName` varchar(45) DEFAULT NULL,
  `keepGpsLogDataForDays` int unsigned DEFAULT NULL,
  `keepVideoDataForDays` int unsigned DEFAULT NULL,
  `avlServer` varchar(45) DEFAULT '',
  `avlServerPort` int unsigned DEFAULT '0',
  `avlPassword` varchar(45) DEFAULT '',
  `tdserverid` varchar(45) DEFAULT '',
  `panicAlertRecipients` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`idx`)
) ;

INSERT INTO `tdconfig` (`idx`, `smtpServer`, `smtpServerPort`, `security`, `recipient`, `authenticationUserName`, `authenticationPassword`, `senderAddr`, `alertRecipients`, `sendSummaryDaily`, `maxConcurrentUpload`, `resumeTransferAfterPause`, `tmSendDaily`, `senderName`, `keepGpsLogDataForDays`, `keepVideoDataForDays`, `avlServer`, `avlServerPort`, `avlPassword`, `tdserverid`, `panicAlertRecipients`) VALUES
(1,	'',	0,	0,	'',	'',	'',	'',	'',	1,	1,	0,	'2023-10-31 19:00:00',	'',	186,	93,	'',	0,	'',	'',	'');

DROP TABLE IF EXISTS `td_alert`;
CREATE TABLE `td_alert` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `dvr_name` varchar(45) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `alert_code` int unsigned NOT NULL,
  `date_time` datetime NOT NULL,
  `param1` int unsigned DEFAULT '0',
  `param2` int unsigned DEFAULT '0',
  PRIMARY KEY (`index`),
  UNIQUE KEY `Index_3` (`date_time`,`dvr_name`,`alert_code`),
  KEY `Index_2` (`date_time`,`dvr_name`)
) ;

DROP TABLE IF EXISTS `vaq`;
CREATE TABLE `vaq` (
  `vaq_id` int NOT NULL AUTO_INCREMENT,
  `vrq_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vrq_vehicle_name` varchar(30) DEFAULT NULL,
  `vfs_vehicle_password` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`vaq_id`) USING BTREE
) ;


DROP TABLE IF EXISTS `vcq`;
CREATE TABLE `vcq` (
  `vcq_id` int NOT NULL AUTO_INCREMENT,
  `vcq_vehicle_name` varchar(30) NOT NULL,
  `vcq_ins_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vcq_ins_user_name` varchar(30) DEFAULT NULL,
  `vcq_start_time` datetime NOT NULL,
  `vcq_end_time` datetime NOT NULL,
  `vcq_comp` int DEFAULT '0',
  `vcq_description` varchar(500) NOT NULL,
  `vcq_channel` varchar(300) NOT NULL DEFAULT '',
  PRIMARY KEY (`vcq_id`)
) ;


DROP TABLE IF EXISTS `vehicle`;
CREATE TABLE `vehicle` (
  `vehicle_id` int NOT NULL AUTO_INCREMENT,
  `vehicle_name` varchar(30) NOT NULL,
  `vehicle_desc` varchar(50) DEFAULT NULL,
  `vehicle_password` varchar(100) DEFAULT NULL,
  `Vehicle_report_mon` varchar(1) DEFAULT 'y',
  `Vehicle_report_tue` varchar(1) DEFAULT 'y',
  `Vehicle_report_wen` varchar(1) DEFAULT 'y',
  `Vehicle_report_thu` varchar(1) DEFAULT 'y',
  `Vehicle_report_fri` varchar(1) DEFAULT 'y',
  `Vehicle_report_sat` varchar(1) DEFAULT 'y',
  `Vehicle_report_sun` varchar(1) DEFAULT 'y',
  `Vehicle_upload_log` varchar(1) DEFAULT 'y',
  `Vehicle_upload_file` varchar(1) DEFAULT 'y',
  `Vehicle_driver_name` varchar(60) DEFAULT NULL,
  `vehicl_config` int unsigned DEFAULT '1',
  `vehicle_plate` varchar(45) DEFAULT ' ',
  `vehicle_model` varchar(45) DEFAULT ' ',
  `vehicle_year` varchar(45) DEFAULT ' ',
  `vehicle_vin` varchar(45) DEFAULT NULL,
  `vehicle_rfid` varchar(45) DEFAULT NULL,
  `vehicle_notes` varchar(45) DEFAULT NULL,
  `vehicle_max_upload_time` int unsigned DEFAULT '60',
  `vehicle_out_of_service` tinyint(1) NOT NULL DEFAULT '0',
  `vehicle_phone` varchar(45) DEFAULT '',
  `vehicle_uid` varchar(45) DEFAULT '',
  `vehicle_live_pwd` varchar(45) DEFAULT '',
  `vehicle_ivuid` varchar(45) DEFAULT '',
  `vehicle_hb` double NOT NULL DEFAULT '0.227',
  `vehicle_qa` double NOT NULL DEFAULT '0.198',
  PRIMARY KEY (`vehicle_id`),
  UNIQUE KEY `vehicle_name` (`vehicle_name`)
) ;


DROP TABLE IF EXISTS `vehicle_current_status`;
CREATE TABLE `vehicle_current_status` (
  `serialNum` int unsigned NOT NULL AUTO_INCREMENT,
  `vehicle_id` varchar(45) NOT NULL,
  `status_time` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `obd_data` tinyint(1) NOT NULL DEFAULT '0',
  `ivu_power_src` varchar(45) NOT NULL DEFAULT '-10000',
  `engine_status` varchar(45) NOT NULL DEFAULT '-10000',
  `ignition` tinyint(1) NOT NULL DEFAULT '0',
  `vehicle_status` varchar(45) NOT NULL DEFAULT '',
  `trip_distance` int NOT NULL DEFAULT '-10000',
  `total_distance` int NOT NULL DEFAULT '-10000',
  `fuel_level` int NOT NULL DEFAULT '-10000',
  `engine_oil_level` int NOT NULL DEFAULT '-10000',
  `coolant_temp` int NOT NULL DEFAULT '-10000',
  `oil_temp` int NOT NULL DEFAULT '-10000',
  `transmission` int NOT NULL DEFAULT '-10000',
  `parking_break` tinyint(1) NOT NULL DEFAULT '0',
  `brake_power` int NOT NULL DEFAULT '0',
  `gas_pedal` int NOT NULL DEFAULT '-10000',
  `engine_load` int NOT NULL DEFAULT '-10000',
  `idling_status` int(1) NOT NULL DEFAULT '-10000',
  `idling_time` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `door_status` tinyint(1) NOT NULL DEFAULT '0',
  `seat_belt` tinyint(1) NOT NULL DEFAULT '0',
  `battery` int NOT NULL DEFAULT '-10000',
  `four_g` tinyint(1) NOT NULL DEFAULT '0',
  `speed` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`serialNum`),
  UNIQUE KEY `Index_2` (`vehicle_id`)
) ;


DROP TABLE IF EXISTS `vehicle_daily`;
CREATE TABLE `vehicle_daily` (
  `idx` int unsigned NOT NULL AUTO_INCREMENT,
  `vd_vehicle_name` varchar(45) NOT NULL,
  `vd_datetime` datetime DEFAULT NULL,
  `vd_distance` double DEFAULT '0',
  `vd_travel_time` int unsigned DEFAULT '0',
  PRIMARY KEY (`idx`),
  KEY `Index_2` (`vd_vehicle_name`,`vd_datetime`)
) ;


DROP TABLE IF EXISTS `vfs`;
CREATE TABLE `vfs` (
  `vfs_id` int NOT NULL AUTO_INCREMENT,
  `vfs_dir` varchar(250) DEFAULT NULL,
  `vfs_name` varchar(50) DEFAULT NULL,
  `vfs_size` int DEFAULT NULL,
  `vfs_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vfs_vehicle_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`vfs_id`)
) ;


DROP TABLE IF EXISTS `vgroup`;
CREATE TABLE `vgroup` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `vehiclelist` mediumtext,
  PRIMARY KEY (`index`)
) ;


DROP TABLE IF EXISTS `videoclip`;
CREATE TABLE `videoclip` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `vehicle_name` varchar(100) NOT NULL,
  `time_start` datetime NOT NULL,
  `time_end` datetime NOT NULL,
  `channel` int unsigned NOT NULL,
  `path` varchar(300) NOT NULL,
  `time_upload` datetime DEFAULT NULL,
  `event_mark_notified` int unsigned DEFAULT '0',
  `request_video_notified` int unsigned DEFAULT '0',
  `tf_status` int DEFAULT '0',
  PRIMARY KEY (`index`),
  KEY `Index_3` (`time_start`),
  KEY `Index_2` (`vehicle_name`,`time_start`) USING BTREE,
  KEY `Index_4` (`path`)
) ;


DROP TABLE IF EXISTS `video_activity_history`;
CREATE TABLE `video_activity_history` (
  `SerialNo` int unsigned NOT NULL AUTO_INCREMENT,
  `handle` int unsigned NOT NULL DEFAULT '0',
  `activity` int unsigned NOT NULL DEFAULT '1',
  `user` varchar(45) NOT NULL DEFAULT '',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `time_length` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`SerialNo`),
  KEY `Index_2` (`handle`)
) ;


DROP TABLE IF EXISTS `video_time_balance`;
CREATE TABLE `video_time_balance` (
  `serialNo` int unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(45) NOT NULL,
  `time_credit` int NOT NULL DEFAULT '0',
  `ref_number` varchar(45) NOT NULL DEFAULT '',
  `time_changed` datetime NOT NULL DEFAULT '2022-01-01 00:00:00',
  `time_balance` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`serialNo`)
) ;


DROP TABLE IF EXISTS `vl`;
CREATE TABLE `vl` (
  `vl_id` int NOT NULL AUTO_INCREMENT,
  `vl_vehicle_name` varchar(30) NOT NULL,
  `vl_datetime` datetime NOT NULL,
  `vl_incident` varchar(30) NOT NULL,
  `vl_sensor` varchar(40) DEFAULT 'no data',
  `vl_lat` double DEFAULT '0',
  `vl_lon` double DEFAULT '0',
  `vl_speed` double DEFAULT NULL,
  `vl_heading` float DEFAULT NULL,
  `vl_driver_name` varchar(60) DEFAULT 'None assigned',
  `eventtype` int DEFAULT '0',
  `vl_time_len` int unsigned DEFAULT NULL,
  `vl_impact_x` double DEFAULT NULL,
  `vl_impact_y` double DEFAULT NULL,
  `vl_impact_z` double DEFAULT NULL,
  `vl_vri` varchar(45) DEFAULT NULL,
  `vl_oid` varchar(45) DEFAULT NULL,
  `vl_cls` varchar(45) DEFAULT NULL,
  `vl_tf_status` int DEFAULT '0',
  `vl_tf_video_available` int DEFAULT '0',
  `vl_obd_value1` double DEFAULT '0',
  `vl_qa` double DEFAULT '7',
  `vl_hb` double DEFAULT '8',
  `vl_fuel` int NOT NULL DEFAULT '-10000',
  `vl_engine_coolant` int NOT NULL DEFAULT '-10000',
  `vl_engine_oil` int NOT NULL DEFAULT '-10000',
  `vl_battery` int NOT NULL DEFAULT '-10000',
  `vl_hard_brake` int NOT NULL DEFAULT '-10000',
  `vl_quick_acceleration` int NOT NULL DEFAULT '-10000',
  PRIMARY KEY (`vl_id`),
  UNIQUE KEY `Index_vehicle` (`vl_vehicle_name`,`vl_datetime`,`vl_incident`) USING BTREE,
  KEY `Index_datetime` (`vl_datetime`),
  KEY `Index_4` (`vl_tf_status`),
  KEY `Index_5` (`vl_speed`,`vl_datetime`)
) ;


DROP TABLE IF EXISTS `vlt_config`;
CREATE TABLE `vlt_config` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `vlt_config_id` varchar(45) DEFAULT NULL,
  `vlt_gpio` varchar(45) DEFAULT NULL,
  `vlt_time_interval` int unsigned DEFAULT NULL,
  `vlt_speed` int unsigned DEFAULT NULL,
  `vlt_impact` varchar(45) DEFAULT NULL,
  `vlt_temperature` int unsigned DEFAULT NULL,
  `vlt_geo` varchar(10000) DEFAULT NULL,
  `vlt_idling` int unsigned DEFAULT NULL,
  `vlt_mp_lost` int unsigned DEFAULT NULL,
  `vlt_mp_low` double DEFAULT NULL,
  `vlt_battery_low` double DEFAULT NULL,
  `vlt_move` int unsigned DEFAULT NULL,
  `vlt_dist_interval` int unsigned DEFAULT NULL,
  `vlt_auto_report` int unsigned DEFAULT NULL,
  `vlt_log_time` int unsigned DEFAULT NULL,
  `vlt_log_distance` int unsigned DEFAULT NULL,
  `vlt_log_speed` int unsigned DEFAULT NULL,
  `vlt_bgeo` int unsigned DEFAULT '0',
  `vlt_gforce_wakeup` varchar(10) DEFAULT NULL,
  `vlt_shutdown_delay` int unsigned DEFAULT NULL,
  `vlt_upload_timeout` int unsigned DEFAULT NULL,
  `vlt_user_name` varchar(45) DEFAULT NULL,
  `vlt_max_count` int unsigned DEFAULT '0',
  `vlt_max_kb` int unsigned DEFAULT '0',
  `vlt_hard_brake` double DEFAULT '0',
  `vlt_quick_acceleration` double DEFAULT '0',
  PRIMARY KEY (`index`)
) ;


DROP TABLE IF EXISTS `vl_special`;
CREATE TABLE `vl_special` (
  `vl_id` int NOT NULL AUTO_INCREMENT,
  `vl_vehicle_name` varchar(30) NOT NULL,
  `vl_datetime` datetime NOT NULL,
  `vl_incident` varchar(30) NOT NULL,
  `vl_lat` double DEFAULT '0',
  `vl_lon` double DEFAULT '0',
  `vl_speed` double DEFAULT NULL,
  `vl_heading` float DEFAULT NULL,
  PRIMARY KEY (`vl_id`),
  UNIQUE KEY `Index_vehicle` (`vl_vehicle_name`,`vl_datetime`,`vl_incident`) USING BTREE
) ;


DROP TABLE IF EXISTS `vl_tmp`;
CREATE TABLE `vl_tmp` (
  `vl_id` int NOT NULL AUTO_INCREMENT,
  `vl_vehicle_name` varchar(30) NOT NULL,
  `vl_datetime` datetime NOT NULL,
  `vl_incident` varchar(30) NOT NULL,
  `vl_sensor` varchar(40) DEFAULT 'no data',
  `vl_lat` double DEFAULT '0',
  `vl_lon` double DEFAULT '0',
  `vl_speed` double DEFAULT NULL,
  `vl_heading` float DEFAULT NULL,
  `vl_driver_name` varchar(60) DEFAULT 'None assigned',
  `eventtype` int DEFAULT '0',
  `vl_time_len` int unsigned DEFAULT NULL,
  `vl_impact_x` double DEFAULT NULL,
  `vl_impact_y` double DEFAULT NULL,
  `vl_impact_z` double DEFAULT NULL,
  `vl_vri` varchar(45) DEFAULT NULL,
  `vl_oid` varchar(45) DEFAULT NULL,
  `vl_cls` varchar(45) DEFAULT NULL,
  `vl_tf_status` int DEFAULT '0',
  `vl_tf_video_available` int DEFAULT '0',
  `vl_obd_value1` double DEFAULT '0',
  `vl_qa` double DEFAULT '7',
  `vl_hb` double DEFAULT '8',
  `vl_fuel` int NOT NULL DEFAULT '-10000',
  `vl_engine_coolant` int NOT NULL DEFAULT '-10000',
  `vl_engine_oil` int NOT NULL DEFAULT '-10000',
  `vl_battery` int NOT NULL DEFAULT '-10000',
  `vl_hard_brake` int NOT NULL DEFAULT '-10000',
  `vl_quick_acceleration` int NOT NULL DEFAULT '-10000',
  PRIMARY KEY (`vl_id`),
  UNIQUE KEY `Index_vehicle` (`vl_vehicle_name`,`vl_datetime`,`vl_incident`) USING BTREE,
  KEY `Index_datetime` (`vl_datetime`),
  KEY `Index_4` (`vl_tf_status`)
) ;


DROP TABLE IF EXISTS `vmq`;
CREATE TABLE `vmq` (
  `vmq_id` int NOT NULL AUTO_INCREMENT,
  `vmq_vehicle_name` varchar(30) NOT NULL,
  `vmq_ins_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vmq_ins_user_name` varchar(30) DEFAULT NULL,
  `vmq_start_time` datetime NOT NULL,
  `vmq_end_time` datetime NOT NULL,
  `vmq_comp` int DEFAULT '0',
  `vmq_description` varchar(500) NOT NULL,
  `vmq_channel` varchar(300) NOT NULL DEFAULT '',
  `vmq_video_files` varchar(50000) NOT NULL DEFAULT '',
  PRIMARY KEY (`vmq_id`)
) ;


DROP TABLE IF EXISTS `vq`;
CREATE TABLE `vq` (
  `vq_id` int NOT NULL AUTO_INCREMENT,
  `vq_vehicle_name` varchar(30) NOT NULL,
  `vq_q_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vq_start_time` datetime DEFAULT NULL,
  `vq_end_time` datetime DEFAULT NULL,
  `vq_file_no` bigint(20) DEFAULT '0',
  `vq_file_size` bigint(20) DEFAULT '0',
  `vq_file_up` bigint(20) DEFAULT '0',
  `vq_speed` bigint(20) DEFAULT '1048576',
  `vq_vehicle_ip` varchar(20) NOT NULL,
  PRIMARY KEY (`vq_id`),
  UNIQUE KEY `vq_vehicle_name` (`vq_vehicle_name`)
) ;


DROP TABLE IF EXISTS `vri`;
CREATE TABLE `vri` (
  `vri_id` varchar(45) NOT NULL,
  `vri_classification` varchar(45) DEFAULT NULL,
  `vri_first_name` varchar(45) DEFAULT NULL,
  `vri_last_name` varchar(45) DEFAULT NULL,
  `vri_driver_license_number` varchar(45) DEFAULT NULL,
  `vri_case_number` varchar(45) DEFAULT NULL,
  `vri_comments` varchar(500) DEFAULT NULL,
  `vri_priority` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`vri_id`)
) ;


DROP TABLE IF EXISTS `vs`;
CREATE TABLE `vs` (
  `vs_id` int NOT NULL AUTO_INCREMENT,
  `vs_vehicle_name` varchar(30) NOT NULL,
  `vs_lastsignon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vs_incident` varchar(30) DEFAULT NULL,
  `vs_sensor` varchar(30) DEFAULT 'no Data',
  `vs_lat` varchar(20) DEFAULT NULL,
  `vs_lon` varchar(20) DEFAULT NULL,
  `vs_speed` int DEFAULT NULL,
  `vs_heading` int DEFAULT NULL,
  `vs_file_up` int DEFAULT '0',
  `vs_read` int DEFAULT '0',
  `vs_dvrread` varchar(1) DEFAULT '0',
  `vs_driver_name` varchar(60) DEFAULT 'None assigned',
  `vs_dvrtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `vs_systemissue` int unsigned NOT NULL DEFAULT '0',
  `vs_eventcount` int unsigned NOT NULL DEFAULT '0',
  `vs_duration` int unsigned NOT NULL DEFAULT '0',
  `vs_upload_speed` int unsigned DEFAULT '0',
  `vs_last_upload_time` datetime DEFAULT NULL,
  `vs_last_speed_time` datetime DEFAULT NULL,
  PRIMARY KEY (`vs_id`),
  UNIQUE KEY `vs_vehicle_name` (`vs_vehicle_name`)
) ;


DROP TABLE IF EXISTS `vt_log`;
CREATE TABLE `vt_log` (
  `serialNo` int unsigned NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL,
  `raw_data` varchar(20000) NOT NULL,
  PRIMARY KEY (`serialNo`),
  KEY `Index_2` (`date_time`)
) ;


DROP TABLE IF EXISTS `vuf`;
CREATE TABLE `vuf` (
  `vuf_id` int NOT NULL AUTO_INCREMENT,
  `vuf_dir` varchar(150) DEFAULT NULL,
  `vuf_name` varchar(50) DEFAULT NULL,
  `vuf_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vuf_vehicle_name` varchar(30) DEFAULT NULL,
  `vuf_size` bigint(20) DEFAULT '0',
  `vfs_dir` varchar(150) DEFAULT NULL,
  `vfs_name` varchar(50) DEFAULT NULL,
  `vfs_vehicle_name` varchar(30) DEFAULT NULL,
  `vfs_size` bigint(20) DEFAULT '0',
  `vuf_flag` varchar(1) DEFAULT '0',
  PRIMARY KEY (`vuf_id`)
) ;


DROP TABLE IF EXISTS `vumq`;
CREATE TABLE `vumq` (
  `vumq_id` int NOT NULL AUTO_INCREMENT,
  `vumq_vehicle_name` varchar(45) NOT NULL,
  `vumq_ins_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vumq_ins_user_name` varchar(30) DEFAULT NULL,
  `vumq_start_time` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `vumq_end_time` datetime NOT NULL,
  `vumq_comp` int DEFAULT '0',
  PRIMARY KEY (`vumq_id`)
) ;


DROP TABLE IF EXISTS `zone`;
CREATE TABLE `zone` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `top` double DEFAULT NULL,
  `left` double DEFAULT NULL,
  `bottom` double DEFAULT NULL,
  `right` double DEFAULT NULL,
  `comment` varchar(45) DEFAULT NULL,
  `type` int unsigned DEFAULT '1',
  `user` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`index`)
) ;
